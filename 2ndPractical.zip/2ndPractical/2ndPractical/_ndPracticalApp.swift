//
//  _ndPracticalApp.swift
//  2ndPractical
//
//  Created by user215333 on 3/9/22.
//

import SwiftUI

@main
struct _ndPracticalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
